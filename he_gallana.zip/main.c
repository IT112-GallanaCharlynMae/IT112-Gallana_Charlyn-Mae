/*
 * BSIT BANK - ATM Program
 * Computer Programming 1 | IT112
 * Instructor: Ralph Angelo E. Baguio
 *
 * Features: Balance Inquiry, Deposit, Withdraw, Exit
 * Starting balance: P500.00 | Minimum balance: P100.00
 */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <errno.h>

#define STARTING_BALANCE 500.00
#define MINIMUM_BALANCE 100.00

int readNumber(const char *prompt, double *value)
{
    char input[100];
    char *endPointer;

    printf("%s", prompt);
    if (fgets(input, sizeof(input), stdin) == NULL)
        return 0;

    errno = 0;
    *value = strtod(input, &endPointer);
    if (endPointer == input || errno != 0)
        return 0;

    while (isspace((unsigned char)*endPointer))
        endPointer++;

    return *endPointer == '\0';
}

void printLine(void)
{
    int i;
    for (i = 0; i < 46; i++)
        printf("=");
    printf("\n");
}

void showHeader(void)
{
    printLine();
    printf("              BSIT BANK ATM\n");
    printf("         Your money, your control!\n");
    printLine();
}

void showMenu(void)
{
    printf("\nPlease select your transaction:\n");
    printf("  [1] Balance Inquiry\n");
    printf("  [2] Deposit\n");
    printf("  [3] Withdraw\n");
    printf("  [4] Exit\n");
}

int main(void)
{
    int choice = 0;
    int transactionNumber = 0;
    double balance = STARTING_BALANCE;
    double amount;
    double remainingBalance;
    double inputValue;

    showHeader();
    printf("Welcome! Your account is ready for this session.\n");
    printf("Starting balance: P%.2f\n", balance);
    printf("Minimum balance rule: Keep at least P%.2f in your account.\n",
           MINIMUM_BALANCE);

    do {
        showMenu();

        if (!readNumber("Enter your choice: ", &inputValue) ||
            inputValue != (int)inputValue) {
            printf("\n[!] Invalid input. Enter a menu number from 1 to 4.\n");
            choice = 0;
            continue;
        }

        choice = (int)inputValue;

        switch (choice) {
            case 1:
                transactionNumber++;
                printLine();
                printf("              BALANCE INQUIRY\n");
                printLine();
                printf("Transaction No. : %03d\n", transactionNumber);
                printf("Available balance: P%.2f\n", balance);
                printf("Account status   : ACTIVE\n");
                printLine();
                break;

            case 2:
                printf("\n--- CASH DEPOSIT ---\n");
                if (!readNumber("Enter amount to deposit: P", &amount)) {
                    printf("[!] Invalid amount. Enter a numeric value.\n");
                    break;
                }

                if (amount <= 0.0) {
                    printf("[!] Deposit must be greater than P0.00.\n");
                } else {
                    balance += amount;
                    transactionNumber++;
                    printf("\n[OK] Deposit successful!\n");
                    printf("Deposited amount : P%.2f\n", amount);
                    printf("New balance      : P%.2f\n", balance);
                    printf("Transaction No.  : %03d\n", transactionNumber);
                }
                break;

            case 3:
                printf("\n--- CASH WITHDRAWAL ---\n");
                if (!readNumber("Enter amount to withdraw: P", &amount)) {
                    printf("[!] Invalid amount. Enter a numeric value.\n");
                    break;
                }

                if (amount <= 0.0) {
                    printf("[!] Withdrawal must be greater than P0.00.\n");
                } else if (amount > balance) {
                    printf("[!] Withdrawal denied! Insufficient funds.\n");
                    printf("Available balance: P%.2f\n", balance);
                } else {
                    remainingBalance = balance - amount;
                    if (remainingBalance < MINIMUM_BALANCE) {
                        printf("\n[!] WITHDRAWAL DENIED!\n");
                        printf("You must maintain at least P%.2f in your account.\n",
                               MINIMUM_BALANCE);
                        printf("Current balance : P%.2f\n", balance);
                        printf("Requested amount: P%.2f\n", amount);
                        printf("Maximum you may withdraw now: P%.2f\n",
                               balance - MINIMUM_BALANCE);
                    } else {
                        balance = remainingBalance;
                        transactionNumber++;
                        printf("\n[OK] Withdrawal successful!\n");
                        printf("Cash withdrawn   : P%.2f\n", amount);
                        printf("Remaining balance: P%.2f\n", balance);
                        printf("Transaction No.  : %03d\n", transactionNumber);
                    }
                }
                break;

            case 4:
                printLine();
                printf("             SESSION SUMMARY\n");
                printLine();
                printf("Transactions completed: %d\n", transactionNumber);
                printf("Final account balance : P%.2f\n", balance);
                printf("Thank you for banking with BSIT BANK!\n");
                printf("       Secure banking, brighter future.\n");
                printLine();
                break;

            default:
                printf("\n[!] Invalid choice. Select 1, 2, 3, or 4.\n");
        }
    } while (choice != 4);

    return 0;
}